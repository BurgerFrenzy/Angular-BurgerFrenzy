import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  token: string = "";

  login(e: string, p: string): boolean {
    const req = this.http.post<Token>('https://reqres.in/api/login', { email: e, password: p });
    req.subscribe(
      (res) => {
        this.token = res.token
      }
    );
    console.log(this.token);

    if (this.token == "")
      return false;
    return true;
  }
}

interface Token {
  token: string;
}